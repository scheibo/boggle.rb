#!/usr/bin/env ruby

File.open("2+2lemma.txt").each_line do |line|
  line.split(",").map(&:strip).each {|w| puts w}
end

